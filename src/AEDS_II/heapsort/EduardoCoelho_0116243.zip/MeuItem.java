package AEDS_II.heapsort;

public class MeuItem implements Item {
    private int chave; // A prioridade

    public MeuItem(int chave) {
        this.chave = chave;
    }

    @Override
    public int compara(Item it) {
        MeuItem item = (MeuItem) it;
        if (this.chave < item.chave) return -1;
        else if (this.chave > item.chave) return 1;
        return 0;
    }

    @Override
    public void alteraChave(Object chave) {
        Integer ch = (Integer) chave;
        this.chave = ch.intValue();
    }

    @Override
    public Object recuperaChave() {
        return new Integer(this.chave);
    }

    // Método extra para ajudar a imprimir na tela no Teste (Letra B)
    @Override
    public String toString() {
        return String.valueOf(this.chave);
    }
}
