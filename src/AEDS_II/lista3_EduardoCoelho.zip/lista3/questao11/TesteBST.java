package AEDS_II.lista3.questao11;

import AEDS_II.lista3.questao10.ArvoreBinaria;

public class TesteBST {
    ArvoreBinaria arvore = new ArvoreBinaria();

        System.out.println("--- INSERINDO NÓS (Q10: Ansiosa) ---");
    
        arvore.insere(new Item(10));
        arvore.insere(new Item(5));
        arvore.insere(new Item(15));
        arvore.insere(new Item(2));  // Filho esq do 5
        arvore.insere(new Item(7));  // Filho dir do 5
        arvore.insere(new Item(20)); // Filho dir do 15
        System.out.println("Nós inseridos com sucesso!");

        System.out.println("\n--- TESTANDO TAMANHO (Q10) ---");
        System.out.println("Tamanho total da árvore: " + arvore.size()); // Deve imprimir 6

        System.out.println("\n--- TESTANDO PERCURSO EM LARGURA (Q5) ---");
        System.out.print("Esperado: 10 5 15 2 7 20 -> Obtido: ");
        arvore.percursoEmLargura();

        System.out.println("\n--- TESTANDO ALTURA (Q7) ---");
    // A altura do 5 deve ser 1 (porque ele tem os filhos 2 e 7 logo abaixo dele)
        System.out.println("Altura do nó 5: " + arvore.alturaDoNo(new Item(5)));

        System.out.println("\n--- TESTANDO PROFUNDIDADE (Q8) ---");
    // A profundidade do 20 deve ser 2 (Raiz(0) -> 15(1) -> 20(2))
        System.out.println("Profundidade do nó 20: " + arvore.profundidadeDoNo(new Item(20)));

        System.out.println("\n--- TESTANDO NÚMERO DE FILHOS (Q9) ---");
    // O nó 5 tem dois filhos (2 e 7).
        System.out.println("Número de filhos do nó 5: " + arvore.numeroDeFilhos(new Item(5)));
    // O nó 20 não tem filhos (é folha).
        System.out.println("Número de filhos do nó 20: " + arvore.numeroDeFilhos(new Item(20)));
}
}
